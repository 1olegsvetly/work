<?php
/**
 * Optimized Product Data Splitting System
 *
 * Поддерживает каталог до десятков тысяч товаров за счёт:
 * - фиксированной разбивки товаров на chunk-файлы;
 * - manifest/index-файла для быстрого поиска по slug/id;
 * - category refs для выборки категорий без чтения всего каталога;
 * - совместимости со старым форматом products.json + products_part_*.json.
 */

if (!defined('PRODUCTS_CHUNK_SIZE')) {
    define('PRODUCTS_CHUNK_SIZE', 1000);
}
if (!defined('PRODUCTS_MAX_FILE_SIZE')) {
    define('PRODUCTS_MAX_FILE_SIZE', 4 * 1024 * 1024);
}
if (!defined('PRODUCTS_SPLIT_PREFIX')) {
    define('PRODUCTS_SPLIT_PREFIX', 'products_part_');
}
if (!defined('PRODUCTS_MANIFEST_FILE')) {
    define('PRODUCTS_MANIFEST_FILE', 'products_manifest');
}

function productsDataDir(): string {
    return __DIR__ . '/../data/';
}

function productsJsonPath(string $name): string {
    return productsDataDir() . $name . '.json';
}

function readJsonFileAssoc(string $path, $default = []) {
    if (!is_file($path)) return $default;
    $content = file_get_contents($path);
    if ($content === false || trim($content) === '') return $default;
    $data = json_decode($content, true);
    return is_array($data) ? $data : $default;
}

function writeJsonFileAtomic(string $path, $data): bool {
    $tmp = $path . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, $path);
}

/**
 * Получить список chunk-файлов товаров. Основной products.json учитывается
 * только если он содержит реальный массив товаров.
 */
function getProductsFileList(): array {
    $dataDir = productsDataDir();
    $files = [];

    $manifest = readJsonFileAssoc(productsJsonPath(PRODUCTS_MANIFEST_FILE), []);
    if (!empty($manifest['chunks']) && is_array($manifest['chunks'])) {
        foreach ($manifest['chunks'] as $chunk) {
            $name = is_array($chunk) ? ($chunk['file'] ?? '') : (string)$chunk;
            if ($name !== '' && is_file(productsJsonPath($name))) {
                $files[] = $name;
            }
        }
        if (!empty($files)) return array_values(array_unique($files));
    }

    $main = readJsonFileAssoc(productsJsonPath('products'), []);
    if (is_array($main) && !empty($main) && !isset($main['_split'])) {
        $files[] = 'products';
    }

    foreach (glob($dataDir . PRODUCTS_SPLIT_PREFIX . '*.json') ?: [] as $file) {
        $basename = basename($file, '.json');
        $files[] = $basename;
    }

    usort($files, function($a, $b) {
        if ($a === 'products') return -1;
        if ($b === 'products') return 1;
        preg_match('/(\d+)/', $a, $ma);
        preg_match('/(\d+)/', $b, $mb);
        return ((int)($ma[1] ?? 0)) <=> ((int)($mb[1] ?? 0));
    });

    return array_values(array_unique($files));
}

function getProductsFromAllFiles(): array {
    $allProducts = [];
    foreach (getProductsFileList() as $file) {
        $chunk = readJsonFileAssoc(productsJsonPath($file), []);
        if (is_array($chunk) && array_is_list($chunk)) {
            foreach ($chunk as $product) {
                if (is_array($product)) $allProducts[] = $product;
            }
        }
    }
    return $allProducts;
}

function shouldSplitProducts($products): bool {
    if (!is_array($products)) return false;
    if (count($products) > PRODUCTS_CHUNK_SIZE) return true;
    $json = json_encode($products, JSON_UNESCAPED_UNICODE);
    return $json !== false && strlen($json) > PRODUCTS_MAX_FILE_SIZE;
}

function productRef(string $file, int $offset): array {
    return ['file' => $file, 'offset' => $offset];
}

function loadProductByRef($ref): ?array {
    if (!is_array($ref)) return null;
    $file = (string)($ref['file'] ?? '');
    $offset = (int)($ref['offset'] ?? -1);
    if ($file === '' || $offset < 0) return null;
    static $chunkCache = [];
    if (!isset($chunkCache[$file])) {
        $chunkCache[$file] = readJsonFileAssoc(productsJsonPath($file), []);
    }
    return isset($chunkCache[$file][$offset]) && is_array($chunkCache[$file][$offset]) ? $chunkCache[$file][$offset] : null;
}

function buildProductsManifestFromFiles(): array {
    $manifest = [
        'version' => 2,
        'optimized' => true,
        'generated_at' => date('c'),
        'chunk_size' => PRODUCTS_CHUNK_SIZE,
        'count' => 0,
        'active_count' => 0,
        'active_quantity' => 0,
        'chunks' => [],
        'slug_index' => [],
        'id_index' => [],
        'category_counts' => [],
        'category_quantity' => [],
        'category_refs' => [],
        'popular_refs' => []
    ];

    foreach (getProductsFileList() as $file) {
        if ($file === PRODUCTS_MANIFEST_FILE) continue;
        $chunk = readJsonFileAssoc(productsJsonPath($file), []);
        if (!is_array($chunk) || !array_is_list($chunk)) continue;

        $chunkMeta = ['file' => $file, 'count' => count($chunk)];
        foreach ($chunk as $offset => $product) {
            if (!is_array($product)) continue;
            $manifest['count']++;
            $ref = productRef($file, (int)$offset);
            $slug = (string)($product['slug'] ?? '');
            $id = (string)($product['id'] ?? '');
            $status = (string)($product['status'] ?? 'active');
            $isActive = $status === 'active';
            $quantity = (int)($product['quantity'] ?? 0);

            if ($slug !== '') $manifest['slug_index'][$slug] = $ref;
            if ($id !== '') $manifest['id_index'][$id] = $ref;
            if (function_exists('isProductHit') && isProductHit($product) && $isActive) {
                $manifest['popular_refs'][] = $ref;
            } elseif (!function_exists('isProductHit') && !empty($product['popular']) && $isActive) {
                $manifest['popular_refs'][] = $ref;
            }

            if ($isActive) {
                $manifest['active_count']++;
                $manifest['active_quantity'] += $quantity;
                $cat = (string)($product['category'] ?? '');
                $sub = (string)($product['subcategory'] ?? '');
                foreach ([$cat, $cat !== '' && $sub !== '' ? $cat . '/' . $sub : ''] as $key) {
                    if ($key === '') continue;
                    if (!isset($manifest['category_counts'][$key])) $manifest['category_counts'][$key] = 0;
                    if (!isset($manifest['category_quantity'][$key])) $manifest['category_quantity'][$key] = 0;
                    if (!isset($manifest['category_refs'][$key])) $manifest['category_refs'][$key] = [];
                    $manifest['category_counts'][$key]++;
                    $manifest['category_quantity'][$key] += $quantity;
                    $manifest['category_refs'][$key][] = $ref;
                }
            }
        }
        $manifest['chunks'][] = $chunkMeta;
    }

    writeJsonFileAtomic(productsJsonPath(PRODUCTS_MANIFEST_FILE), $manifest);
    return $manifest;
}

function getProductsManifest(bool $rebuild = false): array {
    static $manifestCache = null;
    if ($rebuild || $manifestCache === null) {
        $manifest = readJsonFileAssoc(productsJsonPath(PRODUCTS_MANIFEST_FILE), []);
        if ($rebuild || empty($manifest['optimized']) || empty($manifest['chunks'])) {
            $manifest = buildProductsManifestFromFiles();
        }
        $manifestCache = $manifest;
    }
    return is_array($manifestCache) ? $manifestCache : [];
}

function splitProductsIntoFiles($products): void {
    global $_dataCache;
    if (!is_array($products)) $products = [];
    $dataDir = productsDataDir();

    foreach (glob($dataDir . PRODUCTS_SPLIT_PREFIX . '*.json') ?: [] as $file) {
        @unlink($file);
    }

    $partNumber = 1;
    foreach (array_chunk(array_values($products), PRODUCTS_CHUNK_SIZE) as $chunk) {
        writeJsonFileAtomic(productsJsonPath(PRODUCTS_SPLIT_PREFIX . $partNumber), $chunk);
        $partNumber++;
    }

    writeJsonFileAtomic(productsJsonPath('products'), []);
    buildProductsManifestFromFiles();
    if (isset($_dataCache) && is_array($_dataCache)) $_dataCache = [];
}

function mergeProductsFromFiles(): void {
    global $_dataCache;
    $allProducts = getProductsFromAllFiles();
    writeJsonFileAtomic(productsJsonPath('products'), $allProducts);
    foreach (glob(productsDataDir() . PRODUCTS_SPLIT_PREFIX . '*.json') ?: [] as $file) {
        @unlink($file);
    }
    @unlink(productsJsonPath(PRODUCTS_MANIFEST_FILE));
    if (isset($_dataCache) && is_array($_dataCache)) $_dataCache = [];
}

function getProductsWithSplitSupport(): array {
    return getProductsFromAllFiles();
}

function saveProductsWithAutoSplit($products): void {
    global $_dataCache;
    if (!is_array($products)) $products = [];
    // Для стабильной производительности всегда храним товары chunks по 1000 записей.
    splitProductsIntoFiles($products);
    buildProductsManifestFromFiles();
    if (isset($_dataCache) && is_array($_dataCache)) $_dataCache = [];
}

function getProductBySlugFast(string $slug): ?array {
    $manifest = getProductsManifest();
    $ref = $manifest['slug_index'][$slug] ?? null;
    return loadProductByRef($ref);
}

function getProductByIdFast($id): ?array {
    $manifest = getProductsManifest();
    $ref = $manifest['id_index'][(string)$id] ?? null;
    return loadProductByRef($ref);
}

function getProductsByCategoryFast(string $categorySlug, ?string $subcategorySlug = null, int $limit = 0, int $offset = 0): array {
    $manifest = getProductsManifest();
    $key = $subcategorySlug ? ($categorySlug . '/' . $subcategorySlug) : $categorySlug;
    $refs = $manifest['category_refs'][$key] ?? [];
    if ($offset > 0 || $limit > 0) {
        $refs = array_slice($refs, max(0, $offset), $limit > 0 ? $limit : null);
    }
    $products = [];
    foreach ($refs as $ref) {
        $product = loadProductByRef($ref);
        if ($product !== null) $products[] = $product;
    }
    return filterDemoProducts($products);
}

function countProductsByCategoryFast(string $categorySlug, ?string $subcategorySlug = null): int {
    $manifest = getProductsManifest();
    $key = $subcategorySlug ? ($categorySlug . '/' . $subcategorySlug) : $categorySlug;
    return (int)($manifest['category_counts'][$key] ?? 0);
}

function countQuantityByCategoryFast(string $categorySlug, ?string $subcategorySlug = null): int {
    $manifest = getProductsManifest();
    $key = $subcategorySlug ? ($categorySlug . '/' . $subcategorySlug) : $categorySlug;
    return (int)($manifest['category_quantity'][$key] ?? 0);
}

function getMinPriceByCategoryFast(string $categorySlug, ?string $subcategorySlug = null): float {
    $products = getProductsByCategoryFast($categorySlug, $subcategorySlug, 200, 0);
    if (empty($products)) return 0;
    $prices = array_map(fn($p) => (float)($p['price'] ?? 0), $products);
    $prices = array_filter($prices, fn($price) => $price > 0);
    return empty($prices) ? 0 : min($prices);
}

function countTotalProductsFast(): int {
    $manifest = getProductsManifest();
    return (int)($manifest['active_quantity'] ?? 0);
}

function getPopularProductsFast(int $limit = 6): array {
    $manifest = getProductsManifest();
    $refs = array_slice($manifest['popular_refs'] ?? [], 0, max(1, $limit));
    $products = [];
    foreach ($refs as $ref) {
        $product = loadProductByRef($ref);
        if ($product !== null) $products[] = $product;
    }
    return filterDemoProducts(array_slice($products, 0, $limit));
}

function searchProductsFast(string $query, int $limit = 50): array {
    $query = mb_strtolower(trim($query));
    if (mb_strlen($query) < 2) return [];
    $results = [];
    foreach (getProductsFileList() as $file) {
        $chunk = readJsonFileAssoc(productsJsonPath($file), []);
        if (!is_array($chunk)) continue;
        foreach ($chunk as $product) {
            if (!is_array($product) || (($product['status'] ?? 'active') !== 'active')) continue;
            $haystack = mb_strtolower(($product['name'] ?? '') . ' ' . ($product['short_description'] ?? '') . ' ' . ($product['category'] ?? '') . ' ' . ($product['subcategory'] ?? ''));
            if (mb_strpos($haystack, $query) !== false) {
                $results[] = $product;
                if (count($results) >= $limit) return filterDemoProducts($results);
            }
        }
    }
    return filterDemoProducts($results);
}

function getProductsPageFast(int $limit = 40, int $offset = 0): array {
    $limit = max(1, $limit);
    $offset = max(0, $offset);
    $results = [];
    $seen = 0;
    foreach (getProductsFileList() as $file) {
        $chunk = readJsonFileAssoc(productsJsonPath($file), []);
        if (!is_array($chunk)) continue;
        foreach ($chunk as $product) {
            if (!is_array($product) || (($product['status'] ?? 'active') !== 'active')) continue;
            if ($seen++ < $offset) continue;
            $results[] = $product;
            if (count($results) >= $limit) return filterDemoProducts($results);
        }
    }
    return filterDemoProducts($results);
}

?>

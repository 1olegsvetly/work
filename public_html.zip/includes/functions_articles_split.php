<?php
/**
 * Optimized Articles Data Splitting System
 *
 * Статьи выносятся из pages.json в chunk-файлы data/articles_part_*.json
 * с индексом data/articles_manifest.json. pages.json сохраняет остальные
 * страницы и облегчённые метаданные раздела info.
 */

if (!defined('ARTICLES_CHUNK_SIZE')) {
    define('ARTICLES_CHUNK_SIZE', 250);
}
if (!defined('ARTICLES_SPLIT_PREFIX')) {
    define('ARTICLES_SPLIT_PREFIX', 'articles_part_');
}
if (!defined('ARTICLES_MANIFEST_FILE')) {
    define('ARTICLES_MANIFEST_FILE', 'articles_manifest');
}

function articlesDataDir(): string {
    return __DIR__ . '/../data/';
}

function articlesJsonPath(string $name): string {
    return articlesDataDir() . $name . '.json';
}

function readArticlesJson(string $path, $default = []) {
    if (!is_file($path)) return $default;
    $content = file_get_contents($path);
    if ($content === false || trim($content) === '') return $default;
    $data = json_decode($content, true);
    return is_array($data) ? $data : $default;
}

function writeArticlesJsonAtomic(string $path, $data): bool {
    $tmp = $path . '.tmp';
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
    if ($json === false) return false;
    if (file_put_contents($tmp, $json, LOCK_EX) === false) return false;
    return rename($tmp, $path);
}

function getArticleFilesList(): array {
    $manifest = readArticlesJson(articlesJsonPath(ARTICLES_MANIFEST_FILE), []);
    $files = [];
    if (!empty($manifest['chunks']) && is_array($manifest['chunks'])) {
        foreach ($manifest['chunks'] as $chunk) {
            $file = is_array($chunk) ? ($chunk['file'] ?? '') : (string)$chunk;
            if ($file !== '' && is_file(articlesJsonPath($file))) $files[] = $file;
        }
    }
    if (!empty($files)) return $files;
    foreach (glob(articlesDataDir() . ARTICLES_SPLIT_PREFIX . '*.json') ?: [] as $file) {
        $files[] = basename($file, '.json');
    }
    usort($files, function($a, $b) {
        preg_match('/(\d+)/', $a, $ma);
        preg_match('/(\d+)/', $b, $mb);
        return ((int)($ma[1] ?? 0)) <=> ((int)($mb[1] ?? 0));
    });
    return $files;
}

function getArticlesFromFiles(): array {
    $articles = [];
    foreach (getArticleFilesList() as $file) {
        $chunk = readArticlesJson(articlesJsonPath($file), []);
        if (!is_array($chunk) || !array_is_list($chunk)) continue;
        foreach ($chunk as $article) {
            if (is_array($article)) $articles[] = $article;
        }
    }
    return $articles;
}

function articleRef(string $file, int $offset): array {
    return ['file' => $file, 'offset' => $offset];
}

function loadArticleByRef($ref): ?array {
    if (!is_array($ref)) return null;
    $file = (string)($ref['file'] ?? '');
    $offset = (int)($ref['offset'] ?? -1);
    if ($file === '' || $offset < 0) return null;
    static $cache = [];
    if (!isset($cache[$file])) {
        $cache[$file] = readArticlesJson(articlesJsonPath($file), []);
    }
    return isset($cache[$file][$offset]) && is_array($cache[$file][$offset]) ? $cache[$file][$offset] : null;
}

function buildArticlesManifestFromFiles(): array {
    $manifest = [
        'version' => 1,
        'optimized' => true,
        'generated_at' => date('c'),
        'chunk_size' => ARTICLES_CHUNK_SIZE,
        'count' => 0,
        'chunks' => [],
        'slug_index' => [],
        'category_counts' => [],
        'category_refs' => [],
        'all_refs' => []
    ];

    foreach (getArticleFilesList() as $file) {
        $chunk = readArticlesJson(articlesJsonPath($file), []);
        if (!is_array($chunk) || !array_is_list($chunk)) continue;
        $manifest['chunks'][] = ['file' => $file, 'count' => count($chunk)];
        foreach ($chunk as $offset => $article) {
            if (!is_array($article)) continue;
            $manifest['count']++;
            $ref = articleRef($file, (int)$offset);
            $manifest['all_refs'][] = $ref;
            $slug = (string)($article['slug'] ?? '');
            if ($slug !== '') $manifest['slug_index'][$slug] = $ref;
            $category = (string)($article['category'] ?? 'Без категории');
            if (!isset($manifest['category_counts'][$category])) $manifest['category_counts'][$category] = 0;
            if (!isset($manifest['category_refs'][$category])) $manifest['category_refs'][$category] = [];
            $manifest['category_counts'][$category]++;
            $manifest['category_refs'][$category][] = $ref;
        }
    }

    writeArticlesJsonAtomic(articlesJsonPath(ARTICLES_MANIFEST_FILE), $manifest);
    return $manifest;
}

function getArticlesManifest(bool $rebuild = false): array {
    static $cache = null;
    if ($rebuild || $cache === null) {
        $manifest = readArticlesJson(articlesJsonPath(ARTICLES_MANIFEST_FILE), []);
        if ($rebuild || empty($manifest['optimized']) || empty($manifest['chunks'])) {
            $manifest = buildArticlesManifestFromFiles();
        }
        $cache = $manifest;
    }
    return is_array($cache) ? $cache : [];
}

function saveArticlesWithAutoSplit(array $articles): void {
    foreach (glob(articlesDataDir() . ARTICLES_SPLIT_PREFIX . '*.json') ?: [] as $file) {
        @unlink($file);
    }
    $part = 1;
    foreach (array_chunk(array_values($articles), ARTICLES_CHUNK_SIZE) as $chunk) {
        writeArticlesJsonAtomic(articlesJsonPath(ARTICLES_SPLIT_PREFIX . $part), $chunk);
        $part++;
    }
    buildArticlesManifestFromFiles();
}

function optimizePagesArticlesStorage(array $pages): array {
    $articles = $pages['info']['articles'] ?? null;
    if (is_array($articles)) {
        saveArticlesWithAutoSplit($articles);
        $pages['info']['articles'] = [];
        $pages['info']['articles_split'] = true;
        $pages['info']['articles_count'] = count($articles);
    }
    return $pages;
}

function getPagesOptimized(): array {
    $pages = readArticlesJson(articlesJsonPath('pages'), []);
    if (!is_array($pages)) return [];
    if (!empty($pages['info']['articles_split'])) {
        $pages['info']['articles'] = [];
    } elseif (!empty($pages['info']['articles']) && empty(getArticleFilesList())) {
        $pages = optimizePagesArticlesStorage($pages);
        writeArticlesJsonAtomic(articlesJsonPath('pages'), $pages);
        $pages['info']['articles'] = [];
    }
    return $pages;
}

function getPagesBaseOptimized(): array {
    $pages = readArticlesJson(articlesJsonPath('pages'), []);
    if (!is_array($pages)) return [];
    if (!empty($pages['info']['articles_split'])) {
        $pages['info']['articles'] = [];
    }
    return $pages;
}

function savePagesOptimized(array $pages): bool {
    $pages = optimizePagesArticlesStorage($pages);
    return writeArticlesJsonAtomic(articlesJsonPath('pages'), $pages);
}

function getArticles(): array {
    $files = getArticleFilesList();
    if (!empty($files)) return getArticlesFromFiles();
    $pages = readArticlesJson(articlesJsonPath('pages'), []);
    return $pages['info']['articles'] ?? [];
}

function getArticleBySlugFast(string $slug): ?array {
    $manifest = getArticlesManifest();
    $ref = $manifest['slug_index'][$slug] ?? null;
    if ($ref) return loadArticleByRef($ref);
    foreach (getArticles() as $article) {
        if (($article['slug'] ?? '') === $slug) return $article;
    }
    return null;
}

function getArticlesPageFast(int $page = 1, int $perPage = 12, ?string $category = null): array {
    $manifest = getArticlesManifest();
    $refs = $category ? ($manifest['category_refs'][$category] ?? []) : ($manifest['all_refs'] ?? []);
    $refs = array_reverse($refs);
    $total = count($refs);
    $offset = max(0, ($page - 1) * $perPage);
    $pageRefs = array_slice($refs, $offset, $perPage);
    $articles = [];
    foreach ($pageRefs as $ref) {
        $article = loadArticleByRef($ref);
        if ($article !== null) $articles[] = $article;
    }
    return ['articles' => $articles, 'total' => $total, 'pages' => max(1, (int)ceil($total / max(1, $perPage)))];
}

function getArticleCategoriesFast(): array {
    $manifest = getArticlesManifest();
    return array_keys($manifest['category_counts'] ?? []);
}

?>

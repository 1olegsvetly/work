# Система оплаты — ShillCMS v2.7.0

Самодостаточный модуль оплаты, извлечённый из ShillCMS. Поддерживает **YooMoney** (банковская карта / кошелёк) и **Криптовалюту** (BTC, ETH, USDT TRC20/ERC20/BSC/POL, SOL, TON, TRX, BNB, XMR и другие).

---

## Структура папки

```
Система оплаты/
├── core/
│   ├── PaymentHelper.php        — вспомогательные функции (HTTP, форматирование, маски)
│   ├── CryptoPayment.php        — логика криптооплаты (инвойс, верификация, балансы)
│   ├── YooMoneyPayment.php      — логика YooMoney (форма, webhook, верификация)
│   └── OrderManager.php         — создание заказов, выдача товара, статусы
├── webhooks/
│   └── yoomoney_webhook.php     — готовый endpoint для HTTP-уведомлений YooMoney
├── config/
│   ├── payment_config.example.php  — пример конфигурации
│   └── crypto_tokens.example.json  — пример каталога токенов
└── docs/
    ├── README.md                — эта документация
    ├── YOOMONEY_SETUP.md        — инструкция по настройке YooMoney
    └── CRYPTO_SETUP.md          — инструкция по настройке криптооплаты
```

---

## Быстрый старт

### 1. Скопируйте папку `core/` в ваш проект

### 2. Создайте конфиг (на основе `config/payment_config.example.php`)

```php
// config/payment.php
return [
    'methods' => [
        'yoomoney' => ['enabled' => true],
        'crypto'   => ['enabled' => true],
        'demo'     => ['enabled' => false],
    ],
    'yoomoney' => [
        'wallet'               => '4100XXXXXXXXXX',   // Номер кошелька YooMoney
        'notification_secret'  => 'ВАШ_СЕКРЕТ',       // Секрет из настроек уведомлений
        'payment_type'         => 'AC',                // AC = карта, PC = кошелёк
        'success_url'          => 'https://yoursite.ru/oplata/?status=success',
        'fail_url'             => 'https://yoursite.ru/oplata/?status=fail',
    ],
    'crypto' => [
        'notes' => 'Настройте кошельки в crypto_tokens.json',
    ],
];
```

### 3. Подключите нужные классы

```php
require_once 'core/PaymentHelper.php';
require_once 'core/YooMoneyPayment.php';
require_once 'core/CryptoPayment.php';
require_once 'core/OrderManager.php';
```

### 4. Создайте заказ и получите данные для оплаты

```php
// Создание заказа
$order = [
    'order_number' => 'ORDER-' . time(),
    'label'        => 'ORDER-' . time(),
    'email'        => 'user@example.com',
    'items'        => [
        ['product_id' => 1, 'name' => 'Товар', 'price' => 500.0, 'qty' => 1]
    ],
    'totals'       => ['amount' => 500.0, 'quantity' => 1],
];

// YooMoney
$config = require 'config/payment.php';
$paymentData = buildYooMoneyPaymentData($order, $config);
// $paymentData['fields'] — поля для HTML-формы POST на https://yoomoney.ru/quickpay/confirm

// Криптовалюта
$order['crypto'] = ['token_code' => 'USDT_TRC20'];
$paymentData = buildCryptoPaymentData($order);
// $paymentData['invoice'] — данные инвойса (адрес, сумма, QR, таймер)
```

---

## YooMoney

### Принцип работы
1. Пользователь выбирает YooMoney → создаётся заказ → клиент перенаправляется на форму YooMoney
2. После оплаты YooMoney отправляет HTTP-уведомление на ваш webhook URL
3. Webhook верифицирует подпись SHA1 и помечает заказ как оплаченный

### Настройка webhook
- URL webhook: `https://yoursite.ru/webhooks/yoomoney_webhook.php`
- Укажите этот URL в настройках YooMoney → «HTTP-уведомления»
- Укажите тот же `notification_secret` в конфиге и в YooMoney

### Файл webhook
Готовый файл: `webhooks/yoomoney_webhook.php`

---

## Криптовалюта

### Принцип работы
1. Пользователь выбирает токен → создаётся инвойс с уникальной суммой
2. Клиент переводит точную сумму на указанный адрес
3. Система автоматически проверяет баланс кошелька через публичные API
4. При обнаружении оплаты заказ помечается как оплаченный

### Поддерживаемые токены
| Токен | Сеть | Верификация |
|-------|------|-------------|
| BTC | Bitcoin | blockchain.info |
| ETH | Ethereum | Cloudflare RPC |
| USDT_TRC20 | TRON | Tronscan API |
| USDT_ERC20 | Ethereum | Cloudflare RPC |
| USDT_BSC | BNB Smart Chain | Ручная проверка |
| USDT_POL | Polygon | Polygon RPC |
| SOL | Solana | Solana RPC |
| TON | TON | Toncenter API |
| TRX | TRON | Tronscan API |
| BNB | BNB Smart Chain | Ручная проверка |
| XMR | Monero | Ручная проверка |

### Настройка токенов
Отредактируйте `config/crypto_tokens.example.json` — укажите ваши кошельки для каждого токена.

---

## Безопасность

- Никогда не храните `notification_secret` в публичном репозитории
- Используйте HTTPS для всех платёжных страниц
- Проверяйте SHA1-подпись каждого YooMoney-уведомления (уже реализовано в `verifyYooMoneyNotification()`)
- Для криптооплаты используйте уникальную соль суммы (`buildUniqueCryptoAmountSalt`) для различения платежей

---

## Версия

ShillCMS Payment Module v2.7.0 — совместим с PHP 7.4+

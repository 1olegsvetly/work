# Настройка криптовалютной оплаты

## Шаг 1: Настройте кошельки

Откройте `config/crypto_tokens.example.json` и укажите ваши кошельки для каждого токена:

```json
{
  "tokens": [
    {
      "code": "USDT_TRC20",
      "name": "Tether (TRC-20)",
      "network": "TRON",
      "wallet": "ВАШ_TRON_КОШЕЛЁК",
      ...
    }
  ]
}
```

Сохраните как `config/crypto_tokens.json` (или `data/crypto_tokens.json` в вашем проекте).

## Шаг 2: Включите криптооплату в конфиге

```php
'methods' => [
    'crypto' => ['enabled' => true],
],
```

## Шаг 3: Интеграция в ваш проект

```php
require_once 'core/PaymentHelper.php';
require_once 'core/CryptoPayment.php';
require_once 'core/OrderManager.php';

// Загружаем токены и курсы
$tokens     = pmLoadCryptoTokens('config/crypto_tokens.json');
$ratesCache = pmGetCryptoRates('data/crypto_rates.json', $tokens);

// Создаём инвойс
$order['crypto'] = ['token_code' => 'USDT_TRC20'];
$paymentData = buildCryptoPaymentData($order, $tokens, $ratesCache);

if ($paymentData['success']) {
    $invoice = $paymentData['invoice'];
    // $invoice['wallet']               — адрес для оплаты
    // $invoice['expected_amount_text'] — точная сумма
    // $invoice['qr_image_url']         — QR-код
    // $invoice['expires_at']           — время истечения
}
```

## Шаг 4: Автоверификация платежа

```php
// При каждом запросе статуса заказа:
$wasPaid = pmTryAutoVerifyCryptoOrder($order, $tokens);
if ($wasPaid) {
    pmSaveOrders('data/orders.json', $orders);
    // Выдайте товар покупателю
}
```

## Поддерживаемые токены и API верификации

| Токен | Сеть | API верификации | Примечание |
|-------|------|-----------------|------------|
| BTC | Bitcoin | blockchain.info | Автоматически |
| ETH | Ethereum | Cloudflare RPC | Автоматически |
| USDT_TRC20 | TRON | Tronscan API | Автоматически |
| USDT_ERC20 | Ethereum | Cloudflare RPC | Автоматически |
| USDT_POL | Polygon | Polygon RPC | Автоматически |
| SOL | Solana | Solana RPC | Автоматически |
| TON | TON | Toncenter API | Автоматически |
| TRX | TRON | Tronscan API | Автоматически |
| BCH | Bitcoin Cash | Blockchair API | Автоматически |
| LTC | Litecoin | Blockchair API | Автоматически |
| DOGE | Dogecoin | Blockchair API | Автоматически |
| BNB | BNB Chain | — | Ручная проверка |
| USDT_BSC | BNB Chain | — | Ручная проверка |
| XMR | Monero | — | Ручная проверка |

## Принцип верификации

1. При создании инвойса снимается **снимок баланса** кошелька
2. При каждом запросе статуса заказа проверяется **текущий баланс**
3. Если `текущий_баланс - снимок ≥ ожидаемая_сумма (±0.1%)` → платёж подтверждён
4. Каждому заказу присваивается **уникальная соль суммы** для различения платежей

## Курсы валют

Курсы обновляются автоматически через:
- **CoinGecko API** — курсы криптовалют в USD
- **ЦБ РФ API** — курс USD/RUB

Кэш хранится 12 часов в файле `data/crypto_rates.json`.

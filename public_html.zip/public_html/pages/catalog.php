<?php
require_once __DIR__ . '/../includes/functions.php';

$settings = getSettings();
$categories = getCategories();
$perPageCatalog = 40;
$activeProducts = function_exists('getProductsPageFast') ? getProductsPageFast($perPageCatalog, 0) : array_slice(array_filter(getProducts(), fn($p) => ($p['status'] ?? 'active') === 'active'), 0, $perPageCatalog);
$totalProductsCount = function_exists('countTotalProductsFast') ? countTotalProductsFast() : count($activeProducts);

$siteUrl = getCurrentSiteUrl();
$siteName = trim($settings['site']['name'] ?? 'Магазин аккаунтов');
$currentPage = 'catalog';

$metaTags = metaTags(
    'Каталог товаров | ' . $siteName,
    'Полный каталог товаров магазина. Все категории и продукты.',
    'каталог, товары, магазин',
    '/catalog/',
    '/images/ui/favicon.svg',
    'index, follow'
);

$schemaOrg = '<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@graph": [
    {
      "@type": "CollectionPage",
      "name": "Каталог товаров | ' . htmlspecialchars($siteName) . '",
      "description": "Полный каталог товаров магазина. Все категории и продукты.",
      "url": "' . $siteUrl . '/catalog/"
    }
  ]
}
</script>';

// Определяем режим отображения
$current_theme = $settings['site']['template'] ?? 'dark-pro';
$display_mode = 'grid';
if ($current_theme == 'accsmarket') {
    $display_mode = 'list';
} elseif ($current_theme == 'noves-shop') {
    $display_mode = 'grid-clean';
} elseif ($current_theme == 'dark-shopping') {
    $display_mode = 'premium-grid';
}

require __DIR__ . '/../includes/header.php';
?>

<!-- Page Hero -->
<div class="page-hero">
    <div class="container">
        <?php echo breadcrumbs([['name' => 'Главная', 'url' => '/'], ['name' => 'Каталог']]); ?>
        <h1>Каталог товаров</h1>
        <p>Все доступные товары по категориям</p>
    </div>
</div>

<section class="section">
    <div class="container">
        <?php if (empty($categories)): ?>
        <div class="text-center" style="padding:60px 0;">
            <i class="fa-solid fa-box-open" style="font-size:3rem;color:var(--text-muted);margin-bottom:16px;display:block;"></i>
            <h3>Категории не найдены</h3>
            <p class="text-muted mt-8">В каталоге пока нет категорий.</p>
        </div>
        <?php else: ?>
        <!-- Categories Grid -->
        <div class="categories-grid">
            <?php foreach ($categories as $category): ?>
            <a href="/category/<?php echo $category['slug']; ?>/" class="category-card animate-on-scroll">
                <div class="category-icon">
                    <img src="/images/icons/<?php echo $category['icon']; ?>" alt="<?php echo htmlspecialchars($category['name']); ?>" loading="lazy" onerror="this.src='/images/icons/default.svg'">
                </div>
                <h3 class="category-name"><?php echo htmlspecialchars($category['name']); ?></h3>
                <p class="category-count"><?php echo countProductsByCategory($category['slug']); ?> товаров</p>
                <?php if (!empty($category['subcategories'])): ?>
                <div class="category-subcats">
                    <?php foreach (array_slice($category['subcategories'], 0, 3) as $sub): ?>
                    <span class="subcategory-tag"><?php echo htmlspecialchars($sub['name']); ?></span>
                    <?php endforeach; ?>
                    <?php if (count($category['subcategories']) > 3): ?>
                    <span class="subcategory-tag more">+<?php echo count($category['subcategories']) - 3; ?></span>
                    <?php endif; ?>
                </div>
                <?php endif; ?>
            </a>
            <?php endforeach; ?>
        </div>

        <!-- All Products Section -->
        <div class="mt-48">
            <h2 class="mb-24">Все товары <span style="font-size:0.9rem;color:var(--text-muted);font-weight:500;">(показаны первые <?php echo count($activeProducts); ?> из <?php echo $totalProductsCount; ?>)</span></h2>
            <?php if (empty($activeProducts)): ?>
            <div class="text-center" style="padding:40px 0;">
                <p class="text-muted">Товары временно отсутствуют</p>
            </div>
            <?php else: ?>
            <?php $firstBatch = $activeProducts; $restProducts = []; $hasMoreCatalog = ($totalProductsCount > count($activeProducts)); ?>
            <?php if ($display_mode == 'list'): ?>
            <div class="accs-section-header" style="display:grid;grid-template-columns:32px minmax(0,1fr) 110px 140px 90px;align-items:center;gap:8px;padding:7px 14px;background:#2e3135;color:#b0b8c1;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.04em;border-radius:3px 3px 0 0;">
                <span></span>
                <span>Название товара</span>
                <span style="text-align:right">Количество &#8597;</span>
                <span style="text-align:right">Стоимость &#8597;</span>
                <span></span>
            </div>
            <div id="catalogProductsGrid" style="border:1px solid #d7dbe1;border-top:none;background:#fff;border-radius:0 0 3px 3px;overflow:hidden;">
                <?php foreach ($firstBatch as $product): ?>
                <div style="display:grid;grid-template-columns:32px minmax(0,1fr) 110px 140px 90px;align-items:center;gap:8px;padding:9px 14px;border-bottom:1px solid #e5e7eb;background:#fff;transition:background .12s;" onmouseover="this.style.background='#f7f8fa'" onmouseout="this.style.background='#fff'">
                    <img src="/images/icons/<?php echo htmlspecialchars($product['icon'] ?? 'default.svg'); ?>" alt="" style="width:26px;height:26px;object-fit:contain;border-radius:3px;" onerror="this.src='/images/icons/default.svg'">
                    <a href="/item/<?php echo $product['slug']; ?>/" style="font-size:13px;color:#1f7a1f;text-decoration:none;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="<?php echo htmlspecialchars($product['name']); ?>"><?php echo htmlspecialchars($product['name']); ?></a>
                    <span style="text-align:right;font-size:12px;color:#59636d;white-space:nowrap;"><?php echo (int)($product['quantity'] ?? 0); ?> шт.</span>
                    <span style="text-align:right;font-weight:700;color:#1f2937;font-size:13px;white-space:nowrap;"><?php echo formatPrice($product['price']); ?></span>
                    <a href="<?php echo appUrl('/pay/?item=' . $product['slug'] . '&qty=1'); ?>" style="display:inline-block;text-align:center;background:#45ad23;color:#fff;padding:5px 10px;border-radius:2px;font-size:12px;font-weight:700;text-decoration:none;white-space:nowrap;">Купить</a>
                </div>
                <?php endforeach; ?>
            </div>
            <?php else: ?>
            <div class="products-grid" id="catalogProductsGrid">
                <?php foreach ($firstBatch as $i => $product): ?>
                <div class="product-card animate-on-scroll delay-<?php echo min($i % 6, 5); ?>"
                     data-product-id="<?php echo $product['id']; ?>"
                     data-product-slug="<?php echo $product['slug']; ?>"
                     data-price="<?php echo $product['price']; ?>"
                     data-qty="<?php echo $product['quantity']; ?>"
                     onclick="openProductModal(<?php echo $product['id']; ?>)">
                    <div class="product-card-header">
                        <div class="product-icon">
                            <img src="/images/icons/<?php echo $product['icon']; ?>"
                                 alt="<?php echo $product['category']; ?>"
                                 loading="lazy"
                                 onerror="this.src='/images/icons/default.svg'">
                        </div>
                        <div class="product-meta">
                            <div class="product-category"><?php echo ucfirst($product['category']); ?><?php if (!empty($product['subcategory'])): ?> / <?php echo ucfirst($product['subcategory']); ?><?php endif; ?></div>
                            <div class="product-name"><?php echo htmlspecialchars($product['name']); ?></div>
                        </div>
                    </div>
                    <p class="product-description"><?php echo htmlspecialchars($product['short_description']); ?></p>
                    <div class="product-features">
                        <?php foreach (array_slice($product['features'] ?? [], 0, 3) as $feature): ?>
                        <span class="product-feature-tag"><i class="fa-solid fa-check"></i> <?php echo htmlspecialchars($feature); ?></span>
                        <?php endforeach; ?>
                    </div>
                    <div class="product-footer">
                        <div class="product-stock <?php echo $product['quantity'] === 0 ? 'out-of-stock' : ''; ?>">
                            В наличии: <span class="stock-count"><?php echo $product['quantity']; ?> шт.</span>
                        </div>
                        <div class="product-price">
                            
                            <?php echo formatPrice($product['price']); ?>
                        </div>
                    </div>
                    <div style="display:flex;flex-direction:column;gap:8px;margin-top:12px;">
                        <a href="<?php echo appUrl('/pay/?item=' . $product['slug'] . '&qty=1'); ?>" class="product-buy-btn" style="width:100%;" onclick="event.stopPropagation();">
                            <i class="fa-solid fa-cart-shopping"></i> Купить
                        </a>
                        <a href="/item/<?php echo $product['slug']; ?>/" class="product-buy-btn" style="width:100%;background:var(--bg-hover);color:var(--text-secondary);text-align:center;" onclick="event.stopPropagation();" target="_blank">
                            <i class="fa-solid fa-file-lines"></i> Полное описание
                        </a>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <?php endif; // end display_mode == list ?>
            <?php if ($hasMoreCatalog): ?>
            <div class="text-center mt-32" id="loadMoreCatalogWrap">
                <button class="btn btn-secondary btn-lg" id="loadMoreCatalogBtn" onclick="loadMoreCatalog()">
                    <i class="fa-solid fa-rotate"></i> Загрузить ещё (<?php echo $totalProductsCount - count($activeProducts); ?> товаров)
                </button>
            </div>
            <script>
            var catalogLoadOffset = <?php echo count($activeProducts); ?>;
            var catalogTotal = <?php echo (int)$totalProductsCount; ?>;
            var catalogDisplayMode = <?php echo json_encode($display_mode); ?>;
            var catalogLoading = false;
            function loadMoreCatalog() {
                if (catalogLoading) return;
                catalogLoading = true;
                var btn = document.getElementById('loadMoreCatalogBtn');
                if (btn) btn.innerHTML = '<i class="fa-solid fa-spinner fa-spin"></i> Загрузка...';
                fetch('/api/?path=products&limit=40&offset=' + catalogLoadOffset)
                    .then(function(r){ return r.json(); })
                    .then(function(data) {
                        catalogLoading = false;
                        var batch = data.data || [];
                        catalogLoadOffset += batch.length;
                        var grid = document.getElementById('catalogProductsGrid');
                        batch.forEach(function(p) {
                            if (catalogDisplayMode === 'list') {
                                var row = document.createElement('div');
                                row.style.cssText = 'display:grid;grid-template-columns:32px minmax(0,1fr) 110px 140px 90px;align-items:center;gap:8px;padding:9px 14px;border-bottom:1px solid #e5e7eb;background:#fff;transition:background .12s;';
                                row.onmouseover = function(){ this.style.background='#f7f8fa'; };
                                row.onmouseout = function(){ this.style.background='#fff'; };
                                row.innerHTML = '<img src="/images/icons/' + escHtml(p.icon || 'default.svg') + '" alt="" style="width:26px;height:26px;object-fit:contain;border-radius:3px;" onerror="this.src=\'/images/icons/default.svg\'">' +
                                    '<a href="/item/' + escHtml(p.slug) + '/" style="font-size:13px;color:#1f7a1f;text-decoration:none;font-weight:600;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;" title="' + escHtml(p.name) + '">' + escHtml(p.name) + '</a>' +
                                    '<span style="text-align:right;font-size:12px;color:#59636d;white-space:nowrap;">' + (p.quantity || 0) + ' шт.</span>' +
                                    '<span style="text-align:right;font-weight:700;color:#1f2937;font-size:13px;white-space:nowrap;">от ' + formatPrice(p.price) + '</span>' +
                                    '<a href="' + appUrl('/pay/?item=' + encodeURIComponent(p.slug) + '&qty=1') + '" style="display:inline-block;text-align:center;background:#45ad23;color:#fff;padding:5px 10px;border-radius:2px;font-size:12px;font-weight:700;text-decoration:none;white-space:nowrap;">Купить</a>';
                                grid.appendChild(row);
                            } else {
                                var card = document.createElement('div');
                                card.className = 'product-card animated';
                                card.setAttribute('data-product-id', p.id);
                                card.setAttribute('data-product-slug', p.slug);
                                card.setAttribute('data-price', p.price);
                                card.setAttribute('data-qty', p.quantity);
                                card.onclick = function() { openProductModal(p.id); };
                                var features = (p.features || []).slice(0,3).map(function(f){ return '<span class="product-feature-tag"><i class="fa-solid fa-check"></i> ' + escHtml(f) + '</span>'; }).join('');
                                card.innerHTML = '<div class="product-card-header"><div class="product-icon"><img src="/images/icons/' + escHtml(p.icon) + '" alt="" onerror="this.src=\'/images/icons/default.svg\'" loading="lazy"></div><div class="product-meta"><div class="product-category">' + escHtml(p.category) + (p.subcategory ? ' / ' + escHtml(p.subcategory) : '') + '</div><div class="product-name">' + escHtml(p.name) + '</div></div></div><p class="product-description">' + escHtml(p.short_description) + '</p><div class="product-features">' + features + '</div><div class="product-footer"><div class="product-stock ' + (p.quantity === 0 ? 'out-of-stock' : '') + '">В наличии: <span class="stock-count">' + p.quantity + ' шт.</span></div><div class="product-price"> ' + formatPrice(p.price) + '</div></div><div style="display:flex;flex-direction:column;gap:8px;margin-top:12px;"><a href="' + appUrl('/pay/?item=' + encodeURIComponent(p.slug) + '&qty=1') + '" class="product-buy-btn" style="width:100%;" onclick="event.stopPropagation();"><i class="fa-solid fa-cart-shopping"></i> Купить</a></div>';
                                grid.appendChild(card);
                            }
                        });
                        var remaining = catalogTotal - catalogLoadOffset;
                        if (remaining <= 0 || batch.length === 0) {
                            document.getElementById('loadMoreCatalogWrap').style.display = 'none';
                        } else {
                            if (btn) btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Загрузить ещё (' + remaining + ' товаров)';
                        }
                    })
                    .catch(function(e){
                        catalogLoading = false;
                        if (btn) btn.innerHTML = '<i class="fa-solid fa-rotate"></i> Повторить';
                    });
            }
            </script>
            <?php endif; ?>
            <?php endif; ?>
        </div>
        <?php endif; ?>
    </div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>
